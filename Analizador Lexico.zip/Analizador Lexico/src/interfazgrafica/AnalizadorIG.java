
package interfazgrafica;
import java.util.Scanner;
import interfazgrafica.Tipo;

public class AnalizadorIG {
    
    private String valor;
    private Tipo tipo;
    
     /**
     * @return the valor
     */
    public String getValor() {
        return valor;
    }

    /**
     * @param valor the valor to set
     */
    public void setValor(String valor) {
        this.valor = valor;
    }
    

    /**
     * @return the tipo
     */
    public Tipo getTipo() {
        return tipo;
    }

    /**
     * @param tipo the tipo to set
     */
    public void setTipo(Tipo tipo) {
        this.tipo = tipo;
    }
}
       
    enum Tipo{
      
        NUMERO("[0-9]+"),
        OPERADOR("[-|+|/|*]"),
        VARIABLE("[w|x|y|z|W|X|Y|Z]"),
        CONSTANTE("(^PI|^E)"),  
        DESCONOCIDAS("[a-v|A-V]");
     

        // Propiedad para almacenar la cadena asociada a cada tipo
        public final String patron;
 
        // Constructor que asigna la cadena a cada constante enumerada
        Tipo(String Entrada) {
            this.patron = Entrada;
        }
            
 
    }
